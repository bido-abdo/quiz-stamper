"""
stamp_service.py - tiny web service that stamps a graded quiz PDF.

    POST /stamp   (multipart/form-data)
        pdf      the quiz PDF file
        grades   the grades JSON (as text) returned by the n8n grading workflow
        feedback optional, "0" to skip the appended feedback pages
      header  X-API-Key: <your secret>
    -> returns the graded PDF (application/pdf)

    GET /health  -> {"ok": true}

Set the environment variable STAMP_API_KEY to a long random secret on the host.
Run locally:   set STAMP_API_KEY=test & python stamp_service.py
Run in prod:   gunicorn stamp_service:app --workers 2 --timeout 120 --bind 0.0.0.0:$PORT
"""
import hmac
import json
import os

from flask import Flask, Response, jsonify, request

from stamp_quiz import stamp_pdf

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 60 * 1024 * 1024  # 60 MB per request


def _authorised():
    expected = os.environ.get("STAMP_API_KEY", "")
    if not expected:
        return False  # refuse to run open: the key must be configured on the server
    given = request.headers.get("X-API-Key", "")
    return hmac.compare_digest(given.encode(), expected.encode())


@app.get("/health")
def health():
    return jsonify(ok=True)


@app.post("/stamp")
def stamp():
    if not _authorised():
        return jsonify(error="unauthorised"), 401

    pdf = request.files.get("pdf")
    if pdf is None:
        return jsonify(error="missing 'pdf' file field"), 400

    raw = request.form.get("grades")
    if raw is None and "grades" in request.files:
        raw = request.files["grades"].read().decode("utf-8")
    if not raw:
        return jsonify(error="missing 'grades' field"), 400
    try:
        grades = json.loads(raw)
    except ValueError:
        return jsonify(error="'grades' is not valid JSON"), 400

    add_feedback = request.form.get("feedback", "1") != "0"
    try:
        data, warnings = stamp_pdf(pdf.read(), grades, add_feedback=add_feedback)
    except Exception as e:  # bad PDF, bad grades shape...
        return jsonify(error=f"could not stamp: {e}"), 422

    name = (request.form.get("name") or "graded-quiz").rsplit(".", 1)[0] + " - graded.pdf"
    resp = Response(data, mimetype="application/pdf")
    resp.headers["Content-Disposition"] = f'attachment; filename="{name}"'
    resp.headers["X-Stamp-Warnings"] = "; ".join(warnings)[:800].encode("ascii", "replace").decode()
    return resp


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
