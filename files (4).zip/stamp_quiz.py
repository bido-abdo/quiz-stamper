#!/usr/bin/env python3
"""
stamp_quiz.py  -  free, local replacement for the PDF.co stamping steps.

It takes a scanned quiz PDF plus the grades JSON returned by the n8n workflow and
produces a graded PDF:
  * a banner with the total score on page 1
  * a small tick / cross with the marks (e.g. 1/2) next to every answer
  * (optional) feedback pages at the end with the mark-scheme answers for every
    question that lost marks

Install once:      pip install pypdf reportlab requests

Stamp one PDF from a saved grades file:
    python stamp_quiz.py single --pdf quiz.pdf --grades quiz.grades.json --out graded.pdf

Grade + stamp a whole folder through your n8n webhook (resumable, writes results.csv):
    python stamp_quiz.py batch --folder quizzes --out-dir graded ^
        --webhook https://YOUR-N8N/webhook/grade-quiz --exam-id 9280R-Nov24

Expected grades JSON (what the workflow's "Parse Grades" node produces):
    {"examId": "...", "totalAwarded": 6, "totalPossible": 8,
     "questions": [{"number": 1, "studentAnswer": "A", "awardedMarks": 1, "maxMarks": 1,
                    "correct": true, "correctAnswer": "", "feedback": "",
                    "answerBox": {"page": 0, "box": [ymin, xmin, ymax, xmax]}}]}
box values are 0-1000 on the FULL page, (0,0) = top-left, y first.
"""
import argparse
import csv
import io
import json
import math
import sys
import time
from pathlib import Path
from xml.sax.saxutils import escape

try:  # optional: lets the stamper snap each stamp onto the real handwriting
    import numpy as np
except Exception:  # pragma: no cover
    np = None

from pypdf import PdfReader, PdfWriter, Transformation
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

GREEN = colors.HexColor("#0B7A0B")
AMBER = colors.HexColor("#B36B00")
RED = colors.HexColor("#B00020")

EDGE = 12   # stamps stay this far (pt) from the page edge
GAP = 6     # ideal gap between an answer and its stamp
PAD = 3     # clear space kept around every answer box and every other stamp
STEP = 4    # grid step (pt) when searching for free space
FONT = "Helvetica-Bold"


# ----------------------------------------------------------------------------- helpers
def _num(v, default=0.0):
    try:
        n = float(v)
        return n if math.isfinite(n) else default
    except (TypeError, ValueError):
        return default


def _fmt(n):
    n = _num(n)
    return str(int(n)) if float(n).is_integer() else f"{n:g}"


def _clamp(v, lo, hi, default):
    n = _num(v, None)
    if n is None:
        return default
    return max(lo, min(hi, n))


def _overlap(r, o):
    ix = min(r["x"] + r["w"], o["x"] + o["w"]) - max(r["x"], o["x"])
    iy = min(r["y"] + r["h"], o["y"] + o["h"]) - max(r["y"], o["y"])
    return ix * iy if ix > 0 and iy > 0 else 0.0


# ------------------------------------------------------------------- grades -> stamps
def normalise_grades(g):
    """Accept the raw workflow response or the grades object itself."""
    if isinstance(g, dict) and "questions" not in g and isinstance(g.get("grades"), dict):
        g = g["grades"]
    if not isinstance(g, dict):
        raise ValueError("grades JSON must be an object")
    qs = g.get("questions") or []
    total_awarded = g.get("totalAwarded")
    total_possible = g.get("totalPossible")
    if total_awarded is None:
        total_awarded = sum(_num(q.get("awardedMarks")) for q in qs)
    if total_possible is None:
        total_possible = sum(_num(q.get("maxMarks")) for q in qs)
    return {
        "examId": g.get("examId") or "",
        "totalAwarded": _num(total_awarded),
        "totalPossible": _num(total_possible),
        "questions": qs,
    }


def _answer_rect(q, sizes):
    """Answer box in points, origin TOP-LEFT, plus the page index."""
    ab = q.get("answerBox") or {}
    raw = ab.get("box") or ab.get("box_2d") or q.get("box_2d")
    page = int(round(_num(ab.get("page"), 0)))
    page = max(0, min(len(sizes) - 1, page))
    W, H = sizes[page]
    if isinstance(raw, (list, tuple)) and len(raw) == 4 and all(math.isfinite(_num(v, float("nan"))) for v in raw):
        y1, x1, y2, x2 = [_clamp(v, 0, 1000, 0) for v in raw]
        rect = {
            "x": min(x1, x2) / 1000 * W,
            "y": min(y1, y2) / 1000 * H,
            "w": abs(x2 - x1) / 1000 * W,
            "h": abs(y2 - y1) / 1000 * H,
        }
        return page, rect, True
    return page, {"x": 40.0, "y": 120.0, "w": 1.0, "h": 1.0}, False


def build_stamps(grades, sizes):
    stamps = []
    for q in grades["questions"]:
        if q.get("notGraded"):  # the workflow could not grade it: no stamp, listed on the feedback page instead
            continue
        awarded, maxm = _num(q.get("awardedMarks")), _num(q.get("maxMarks"))
        full = awarded >= maxm if maxm > 0 else bool(q.get("correct"))
        if full:
            kind, color, size = "tick", GREEN, 13
        elif awarded > 0:
            kind, color, size = "tick", AMBER, 14
        else:
            kind, color, size = "cross", RED, 15
        text = f"{_fmt(awarded)}/{_fmt(maxm)}"
        page, rect, located = _answer_rect(q, sizes)
        w = 2 + size * 0.95 + 3 + stringWidth(text, FONT, size) + 3
        stamps.append({
            "q": q, "kind": kind, "color": color, "size": size, "text": text,
            "w": w, "h": size + 4, "page": page, "ans": rect, "located": located,
            "x": 0.0, "y": 0.0, "overlaps": False, "full": full,
        })
    return stamps


# --------------------------------------------------- reading the scan (handwriting finder)
def _despeckle(m, min_neighbours=3):
    p = np.pad(m, 1)
    h, w = m.shape
    n = sum(p[dy:dy + h, dx:dx + w].astype(np.uint8) for dy in range(3) for dx in range(3)) - m.astype(np.uint8)
    return m & (n >= min_neighbours)


def _page_maps(page, max_side=1400):
    """Return {'ink': bool array (blue pen), 'dark': bool array (any dark pixel)} for the page scan, or None."""
    if np is None:
        return None
    try:
        imgs = list(page.images)
        if not imgs:
            return None
        img = max((i.image for i in imgs), key=lambda im: im.size[0] * im.size[1]).convert("RGB")
        w, h = img.size
        scale = max_side / max(w, h)
        if scale < 1:
            img = img.resize((max(1, int(w * scale)), max(1, int(h * scale))))
        a = np.asarray(img).astype(np.int16)
        R, G, B = a[..., 0], a[..., 1], a[..., 2]
        ink = _despeckle((R < 150) & ((B - R) > 10))          # handwriting in blue / blue-black pen
        dark = ((R + G + B) // 3) < 140                        # anything dark: printed text, shadows, pen
        integral = np.pad(dark.astype(np.int32).cumsum(0).cumsum(1), ((1, 0), (1, 0)))
        return {"ink": ink, "dark": dark, "integral": integral}
    except Exception:
        return None


def _dark_fraction(maps, rect, W, H):
    """Share of dark pixels inside rect (points, top-left origin)."""
    ii = maps["integral"]
    h_px, w_px = ii.shape[0] - 1, ii.shape[1] - 1
    x1 = int(max(0, min(w_px, rect["x"] / W * w_px)))
    x2 = int(max(0, min(w_px, (rect["x"] + rect["w"]) / W * w_px)))
    y1 = int(max(0, min(h_px, rect["y"] / H * h_px)))
    y2 = int(max(0, min(h_px, (rect["y"] + rect["h"]) / H * h_px)))
    if x2 <= x1 or y2 <= y1:
        return 0.0
    tot = ii[y2, x2] - ii[y1, x2] - ii[y2, x1] + ii[y1, x1]
    return float(tot) / float((x2 - x1) * (y2 - y1))


def _blobs(ink, W, H, cell=8, dil_x=5, dil_y=2):
    """Group the pen strokes into blobs (one per written answer). Boxes are in points, top-left origin."""
    h_px, w_px = ink.shape
    ch, cw = h_px // cell, w_px // cell
    if ch < 3 or cw < 3:
        return []
    act = ink[:ch * cell, :cw * cell].reshape(ch, cell, cw, cell).sum(axis=(1, 3)) >= 3
    g = act.copy()
    for d in range(1, dil_x + 1):          # join the words of one line
        g[:, d:] |= act[:, :-d]
        g[:, :-d] |= act[:, d:]
    g2 = g.copy()
    for d in range(1, dil_y + 1):          # join the lines of one answer
        g2[d:, :] |= g[:-d, :]
        g2[:-d, :] |= g[d:, :]
    seen = np.zeros_like(g2, dtype=bool)
    sx, sy = W / (cw * cell), H / (ch * cell)
    blobs = []
    for y0, x0 in zip(*np.nonzero(g2)):
        if seen[y0, x0]:
            continue
        stack, cells = [(y0, x0)], []
        seen[y0, x0] = True
        while stack:
            y, x = stack.pop()
            cells.append((y, x))
            for ny, nx in ((y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)):
                if 0 <= ny < ch and 0 <= nx < cw and g2[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True
                    stack.append((ny, nx))
        real = [(y, x) for y, x in cells if act[y, x]]
        if len(real) < 3:
            continue
        ys = [y for y, _ in real]
        xs = [x for _, x in real]
        blobs.append({
            "x": min(xs) * cell * sx, "y": min(ys) * cell * sy,
            "w": (max(xs) - min(xs) + 1) * cell * sx, "h": (max(ys) - min(ys) + 1) * cell * sy,
            "n": len(real),
        })
    blobs.sort(key=lambda b: b["y"] + b["h"] / 2)
    return blobs


def _snap_page(maps, items, W, H):
    """items = [(key, rough_rect)] for one page, returns {key: snapped_rect}.

    Each rough box is snapped onto the nearest blob of pen strokes, but only when that blob is close (the model's
    box is normally within a few percent). A blob is used for one question only; anything unclear stays as it is."""
    if not items:
        return {}
    blobs = _blobs(maps["ink"], W, H)
    if not blobs:
        return {}
    TMAX = 0.05 * H

    def cost(r, b):
        qx, qy = r["x"] + r["w"] / 2, r["y"] + r["h"] / 2
        bx, by = b["x"] + b["w"] / 2, b["y"] + b["h"] / 2
        # boxes that overlap are always close, however tall the blob is
        oy = min(r["y"] + r["h"], b["y"] + b["h"]) - max(r["y"], b["y"])
        ox = min(r["x"] + r["w"], b["x"] + b["w"]) - max(r["x"], b["x"])
        d = math.hypot(0.5 * (qx - bx), qy - by)
        if oy > 0 and ox > 0:
            return d * 0.5
        if ox <= 0:               # the model is usually right about the horizontal position: ticks and crosses
            return d * 2.0        # drawn elsewhere on the page should not win over the real answer
        return d

    pairs = sorted(((cost(r, b), qi, bj) for qi, (_, r) in enumerate(items) for bj, b in enumerate(blobs)),
                   key=lambda t: t[0])
    taken_q, taken_b, match = set(), set(), {}
    for c, qi, bj in pairs:
        if c >= TMAX:
            break
        if qi in taken_q or bj in taken_b:
            continue
        taken_q.add(qi)
        taken_b.add(bj)
        match[qi] = bj
    used = set(match.values())
    out = {}
    for qi, bj in match.items():
        key, rough = items[qi]
        b = dict(blobs[bj])
        for k, o in enumerate(blobs):                        # extra lines of the same answer inside the rough box
            if k in used:
                continue
            cy = o["y"] + o["h"] / 2
            if rough["y"] - 15 <= cy <= rough["y"] + rough["h"] + 15 and \
                    o["x"] < rough["x"] + rough["w"] and o["x"] + o["w"] > rough["x"]:
                x1, y1 = min(b["x"], o["x"]), min(b["y"], o["y"])
                x2, y2 = max(b["x"] + b["w"], o["x"] + o["w"]), max(b["y"] + b["h"], o["y"] + o["h"])
                b.update(x=x1, y=y1, w=x2 - x1, h=y2 - y1)
                used.add(k)
        pad = 2.0
        out[key] = {"x": b["x"] - pad, "y": b["y"] - pad, "w": b["w"] + 2 * pad, "h": b["h"] + 2 * pad}
    return out


# ------------------------------------------------------------------------- placing stamps
def place_stamps(stamps, sizes, banner_rect, maps=None):
    """Put every stamp in the free spot closest to its own answer (beside > below > above > left)."""
    maps = maps or {}
    obstacles = {}

    def add_obs(page, r, pad):
        obstacles.setdefault(page, []).append(
            {"x": r["x"] - pad, "y": r["y"] - pad, "w": r["w"] + 2 * pad, "h": r["h"] + 2 * pad})

    add_obs(0, banner_rect, 3)
    for s in stamps:
        add_obs(s["page"], s["ans"], PAD)

    def score_of(s, x, y):
        A = s["ans"]
        ref_y = A["y"] + A["h"] / 2 - s["h"] / 2          # prefer the stamp level with the middle of the answer
        dx = max(A["x"] - (x + s["w"]), x - (A["x"] + A["w"]), 0)
        dy = max(A["y"] - (y + s["h"]), y - (A["y"] + A["h"]), 0)
        score = dx + dy
        if x >= A["x"] + A["w"] - 1:
            score += 0.1 * abs(y - ref_y)
        elif y >= A["y"] + A["h"] - 1:
            score += 2 + 0.1 * abs(x - A["x"])
        elif y + s["h"] <= A["y"] + 1:
            score += 6 + 0.1 * abs(x - A["x"])
        else:
            score += 10
        return score

    def place(s):
        W, H = sizes[s["page"]]
        obs = obstacles.get(s["page"], [])
        pm = maps.get(s["page"])
        A = s["ans"]
        min_x, max_x = EDGE, W - EDGE - s["w"]
        min_y, max_y = EDGE, H - EDGE - s["h"]

        def cost(x, y):
            r = {"x": x, "y": y, "w": s["w"], "h": s["h"]}
            ov = sum(_overlap(r, o) for o in obs)
            if pm is not None:  # do not cover printed text or other handwriting either
                frac = _dark_fraction(pm, r, W, H)
                if frac > 0.10:
                    ov += frac * s["w"] * s["h"]
            return ov

        def evaluate(cands):
            best = fb = None
            for cx, cy in cands:
                x = max(min_x, min(max_x, cx))
                y = max(min_y, min(max_y, cy))
                ov = cost(x, y)
                sc = score_of(s, x, y)
                if ov == 0:
                    if best is None or sc < best[2]:
                        best = (x, y, sc)
                elif fb is None or ov < fb[3] or (ov == fb[3] and sc < fb[2]):
                    fb = (x, y, sc, ov)
            return best, fb

        mid = A["y"] + A["h"] / 2 - s["h"] / 2
        near = [
            (A["x"] + A["w"] + GAP, mid),
            (A["x"] + A["w"] + GAP, A["y"]),
            (A["x"] + A["w"] + GAP, A["y"] + A["h"] - s["h"]),
            (A["x"], A["y"] + A["h"] + GAP),
            (A["x"] + A["w"] - s["w"], A["y"] + A["h"] + GAP),
            (A["x"], A["y"] - s["h"] - GAP),
            (A["x"] - s["w"] - GAP, mid),
        ]
        # also try every free spot in a small neighbourhood of the answer (dense pages, "[1 mark]" labels...)
        local = [(x, y)
                 for y in range(int(A["y"] - s["h"] - 20), int(A["y"] + A["h"] + 20), 3)
                 for x in range(int(A["x"] + A["w"] - 20), int(A["x"] + A["w"] + 70), 3)]
        best, fb = evaluate(near + local)
        if best is None:  # nothing free right next to the answer -> search the whole page
            grid = [(x, y)
                    for y in range(int(min_y), int(max_y) + 1, STEP)
                    for x in range(int(min_x), int(max_x) + 1, STEP)]
            g_best, g_fb = evaluate(grid)
            best = g_best
            if fb is None or (g_fb is not None and g_fb[3] < fb[3]):
                fb = g_fb or fb
        pick = best or fb
        s["x"], s["y"] = pick[0], pick[1]
        s["overlaps"] = best is None
        add_obs(s["page"], {"x": s["x"], "y": s["y"], "w": s["w"], "h": s["h"]}, PAD)

    # wrong answers first so they get the best spots
    for s in sorted(stamps, key=lambda s: (s["full"], _num(s["q"].get("number")))):
        place(s)


# ---------------------------------------------------------------------------- drawing
def _draw_icon(c, kind, x, y, s, color):
    c.saveState()
    c.setStrokeColor(color)
    c.setLineWidth(max(1.6, s * 0.14))
    c.setLineCap(1)
    c.setLineJoin(1)
    if kind == "tick":
        p = c.beginPath()
        p.moveTo(x + 0.05 * s, y + 0.50 * s)
        p.lineTo(x + 0.36 * s, y + 0.15 * s)
        p.lineTo(x + 0.95 * s, y + 0.85 * s)
        c.drawPath(p, stroke=1, fill=0)
    else:
        c.line(x + 0.15 * s, y + 0.15 * s, x + 0.85 * s, y + 0.85 * s)
        c.line(x + 0.15 * s, y + 0.85 * s, x + 0.85 * s, y + 0.15 * s)
    c.restoreState()


def _overlay_page(stamps, banner, banner_rect, page_index, W, H):
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(W, H))
    if page_index == 0:
        c.saveState()
        c.setFillColor(colors.white)
        c.setFillAlpha(0.9)
        c.rect(banner_rect["x"] - 3, H - banner_rect["y"] - banner_rect["h"] - 3,
               banner_rect["w"] + 6, banner_rect["h"] + 6, stroke=0, fill=1)
        c.restoreState()
        c.setFillColor(RED)
        c.setFont(FONT, banner_rect["size"])
        c.drawString(banner_rect["x"], H - banner_rect["y"] - banner_rect["size"], banner)
    for s in stamps:
        if s["page"] != page_index:
            continue
        bx, by = s["x"], H - s["y"] - s["h"]
        if not s["overlaps"]:  # only draw a backing when it can't hide an answer
            c.saveState()
            c.setFillColor(colors.white)
            c.setFillAlpha(0.85)
            c.roundRect(bx, by, s["w"], s["h"], 3, stroke=0, fill=1)
            c.restoreState()
        _draw_icon(c, s["kind"], bx + 2, by + 2, s["size"], s["color"])
        c.setFillColor(s["color"])
        c.setFont(FONT, s["size"])
        c.drawString(bx + 2 + s["size"] * 0.95 + 3, by + 2 + s["size"] * 0.18, s["text"])
    c.showPage()  # makes sure a page exists even when nothing was drawn on it
    c.save()
    buf.seek(0)
    return PdfReader(buf).pages[0]


# ------------------------------------------------------------------- feedback pages
def build_feedback_pdf(grades):
    awarded, possible = grades["totalAwarded"], grades["totalPossible"]
    pct = round(awarded / possible * 100) if possible else 0
    qs = grades["questions"]

    base = getSampleStyleSheet()["Normal"]
    body = ParagraphStyle("body", parent=base, fontName="Helvetica", fontSize=10, leading=14)
    h1 = ParagraphStyle("h1", parent=body, fontName=FONT, fontSize=22, leading=26, textColor=RED)
    h2 = ParagraphStyle("h2", parent=body, fontName=FONT, fontSize=13, leading=16, spaceBefore=14, spaceAfter=6)
    sub = ParagraphStyle("sub", parent=body, textColor=colors.HexColor("#555555"))
    head = ParagraphStyle("head", parent=body, fontName=FONT, fontSize=11)

    story = [
        Paragraph("Feedback", h1),
        Paragraph(f"Exam {escape(str(grades['examId']))} &mdash; Score {_fmt(awarded)}/{_fmt(possible)} ({pct}%)", sub),
        Paragraph("Marks by question", h2),
    ]

    chips, chip_styles = [], []
    per_row = 8
    row = []
    for i, q in enumerate(qs):
        a, m = _num(q.get("awardedMarks")), _num(q.get("maxMarks"))
        bg, fg = ("#E3F4E3", GREEN) if a >= m else (("#FFF1D6", AMBER) if a > 0 else ("#FBE3E6", RED))
        col = i % per_row
        row.append(Paragraph(f"Q{escape(str(q.get('number', i + 1)))}&nbsp;&nbsp;{_fmt(a)}/{_fmt(m)}",
                             ParagraphStyle("chip", parent=body, fontName=FONT, fontSize=9, textColor=fg)))
        chip_styles.append(("BACKGROUND", (col, len(chips)), (col, len(chips)), colors.HexColor(bg)))
        if col == per_row - 1 or i == len(qs) - 1:
            row += [""] * (per_row - len(row))
            chips.append(row)
            row = []
    if chips:
        t = Table(chips, colWidths=[62] * per_row)
        t.setStyle(TableStyle(chip_styles + [
            ("BOX", (0, 0), (-1, -1), 0, colors.white),
            ("INNERGRID", (0, 0), (-1, -1), 2, colors.white),
            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t)

    story.append(Paragraph("Questions to review", h2))
    review = [q for q in qs if _num(q.get("awardedMarks")) < _num(q.get("maxMarks"))]
    if not review:
        story.append(Paragraph("Full marks on every question - well done!", body))
    for q in review:
        a, m = _num(q.get("awardedMarks")), _num(q.get("maxMarks"))
        lines = [
            [Paragraph(f"Question {escape(str(q.get('number', '')))}", head),
             Paragraph(f"<font color='{'#B36B00' if a > 0 else '#B00020'}'><b>{_fmt(a)}/{_fmt(m)}</b></font>",
                       ParagraphStyle("r", parent=body, alignment=2))],
            [Paragraph(f"<b>Your answer:</b> {escape(str(q.get('studentAnswer') or '(no answer found)'))}", body), ""],
        ]
        if q.get("correctAnswer"):
            lines.append([Paragraph(f"<b>Mark scheme answer:</b> {escape(str(q['correctAnswer']))}", body), ""])
        if q.get("feedback"):
            lines.append([Paragraph(f"<b>Feedback:</b> {escape(str(q['feedback']))}", body), ""])
        card = Table(lines, colWidths=[400, 100])
        card.setStyle(TableStyle([
            ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#DDDDDD")),
            ("SPAN", (0, 1), (1, 1)),
            *[("SPAN", (0, r), (1, r)) for r in range(2, len(lines))],
            ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story += [KeepTogether([card]), Spacer(1, 8)]

    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=A4, leftMargin=40, rightMargin=40, topMargin=40, bottomMargin=40,
                      title="Feedback").build(story)
    buf.seek(0)
    return PdfReader(buf)


# ----------------------------------------------------------------------- main function
def stamp_pdf(pdf_bytes, grades, add_feedback=True):
    """Return (graded_pdf_bytes, warnings)."""
    grades = normalise_grades(grades)
    reader = PdfReader(io.BytesIO(pdf_bytes))
    warnings = []

    sizes = []
    for i, p in enumerate(reader.pages):
        sizes.append((float(p.mediabox.width), float(p.mediabox.height)))
        if p.get("/Rotate"):
            warnings.append(f"page {i + 1} has /Rotate={p.get('/Rotate')}; stamp positions may be off")

    awarded, possible = grades["totalAwarded"], grades["totalPossible"]
    pct = round(awarded / possible * 100) if possible else 0
    not_graded = [str(q.get("number")) for q in grades["questions"] if q.get("notGraded")]
    banner = f"GRADED  {_fmt(awarded)}/{_fmt(possible)}  ({pct}%)  -  Exam {grades['examId']}"
    if not_graded:
        banner += f"  -  {len(not_graded)} NOT GRADED"
        warnings.append("not graded (mark by hand): Q" + ", Q".join(not_graded))
    banner_size = 18
    while banner_size > 10 and stringWidth(banner, FONT, banner_size) > sizes[0][0] - 80:
        banner_size -= 1  # shrink the banner so it always fits on the page
    banner_rect = {"x": 40.0, "y": 24.0, "w": stringWidth(banner, FONT, banner_size), "h": banner_size + 6.0,
                   "size": banner_size}

    stamps = build_stamps(grades, sizes)

    # Look at the scan itself: snap every rough model box onto the real handwriting
    maps = {}
    for i, p in enumerate(reader.pages):
        m = _page_maps(p)
        if m is not None:
            maps[i] = m
    for i, m in maps.items():
        W, H = sizes[i]
        items = [(k, dict(s["ans"])) for k, s in enumerate(stamps)
                 if s["page"] == i and s["located"] and str(s["q"].get("studentAnswer") or "").strip()]
        try:
            snapped = _snap_page(m, items, W, H)
        except Exception:  # never let the refinement break the stamping
            snapped = {}
        for k, r in snapped.items():
            stamps[k]["ans"], stamps[k]["snapped"] = r, True
    place_stamps(stamps, sizes, banner_rect, maps)

    for s in stamps:
        n = s["q"].get("number", "?")
        if not s["located"]:
            warnings.append(f"Q{n}: no answer box from the model - stamp placed at a default spot")
        elif s["overlaps"]:
            warnings.append(f"Q{n}: page is crowded - stamp overlaps something")

    writer = PdfWriter()
    for i, page in enumerate(reader.pages):
        overlay = _overlay_page(stamps, banner, banner_rect, i, *sizes[i])
        left, bottom = float(page.mediabox.left), float(page.mediabox.bottom)
        if left or bottom:
            page.merge_transformed_page(overlay, Transformation().translate(left, bottom))
        else:
            page.merge_page(overlay)
        writer.add_page(page)

    if add_feedback:
        for p in build_feedback_pdf(grades).pages:
            writer.add_page(p)

    out = io.BytesIO()
    writer.write(out)
    return out.getvalue(), warnings


# ------------------------------------------------------------------ measuring grid (for the model)
def add_grid(pdf_bytes):
    """Return a copy of the PDF with a light, labelled 0-1000 measuring grid drawn on every page.

    The copy is only sent to the grading model: it can read where each answer is straight off the grid, which is far
    more accurate than estimating pixel positions. The stamps are always drawn on the ORIGINAL pdf."""
    reader = PdfReader(io.BytesIO(pdf_bytes))
    writer = PdfWriter()
    magenta = colors.Color(0.85, 0.0, 0.65)
    for page in reader.pages:
        W, H = float(page.mediabox.width), float(page.mediabox.height)
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=(W, H))
        c.setFont("Helvetica-Bold", 7)
        for v in range(0, 1001, 50):
            major = v % 100 == 0
            x, y = v / 1000 * W, H - v / 1000 * H
            c.saveState()
            c.setStrokeColor(magenta)
            c.setStrokeAlpha(0.42 if major else 0.16)
            c.setLineWidth(0.5 if major else 0.3)
            c.line(x, 0, x, H)
            c.line(0, y, W, y)
            c.restoreState()
            if major:
                label = str(v)
                c.setFillColor(magenta)
                for (tx, ty) in ((x + 1.5, H - 8), (x + 1.5, 2)):          # x labels along the top and bottom edges
                    c.drawString(min(tx, W - 18), ty, label)
                for (tx, ty) in ((1.5, y + 1.5), (W - 18, y + 1.5)):        # y labels along the left and right edges
                    c.drawString(tx, min(max(ty, 10), H - 10), label)
        c.showPage()
        c.save()
        buf.seek(0)
        page.merge_page(PdfReader(buf).pages[0])
        writer.add_page(page)
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


# ------------------------------------------------------------------------------ CLI
def cmd_single(a):
    grades = json.loads(Path(a.grades).read_text(encoding="utf-8"))
    data, warns = stamp_pdf(Path(a.pdf).read_bytes(), grades, add_feedback=not a.no_feedback)
    Path(a.out).write_bytes(data)
    for w in warns:
        print("  warning:", w)
    print("Saved", a.out)


class _NoRetry(Exception):
    """Raised when trying again would only grade (and charge) the same quiz twice."""


def _call_webhook(requests, url, pdf_path, exam_id, headers, retries, timeout, grid=False):
    """Start a grading job and wait for its result.

    The webhook answers straight away with a jobId; the workflow then grades in the background and the result is
    fetched from <webhook>-result. (A single long request gets cut off by n8n Cloud after about 100 seconds.)"""
    payload = pdf_path.read_bytes()
    if grid:
        try:
            payload = add_grid(payload)          # optional measuring grid (off by default)
        except Exception:
            grid = False
    last = None
    for attempt in range(retries + 1):
        try:
            form = {}
            if exam_id:
                form["examId"] = exam_id
            if grid:
                form["grid"] = "1"
            r = requests.post(url, files={"data": (pdf_path.name, payload, "application/pdf")},
                              data=form or None, headers=headers, timeout=180)
            if r.status_code >= 400:
                raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
            resp = r.json()
            g = resp if "questions" in resp else resp.get("grades")          # old-style: grades straight away
            if isinstance(g, dict) and g.get("questions"):
                return g
            job = resp.get("jobId")
            if not job:
                raise RuntimeError("the webhook did not start a grading job: " + json.dumps(resp)[:200])
            result_url = url.rstrip("/") + "-result"
            deadline = time.time() + timeout
            misses = 0
            while time.time() < deadline:
                time.sleep(4)
                try:
                    rr = requests.get(result_url, params={"jobId": job}, headers=headers, timeout=60)
                    if rr.status_code >= 400:
                        raise RuntimeError(f"HTTP {rr.status_code}")
                    j = rr.json()
                    misses = 0
                except Exception as e:                                        # a hiccup while asking: ask again
                    misses += 1
                    if misses >= 8:
                        raise _NoRetry(f"could not reach the result page ({e}); the job {job} may still finish in n8n")
                    continue
                status = j.get("status")
                if status == "processing":
                    continue
                res = j.get("result") or {}
                if status == "error" or not res.get("questions"):
                    raise RuntimeError(f"n8n could not grade this quiz (job {job}): "
                                       + str(res.get("error") or json.dumps(j))[:300])
                return res
            raise _NoRetry(f"still no result after {timeout} seconds (job {job}) - look at that execution in n8n")
        except _NoRetry:
            raise
        except Exception as e:  # network error, bad response...
            last = e
            print(f"    {pdf_path.name}: attempt {attempt + 1} failed: {str(e)[:300]}", flush=True)
            if attempt < retries:
                print("    trying once more (this grades the quiz again and costs again)", flush=True)
                time.sleep(5 * (attempt + 1))
    raise last


def cmd_batch(a):
    import threading
    from concurrent.futures import ThreadPoolExecutor

    import requests  # imported here so `single` works without it

    folder, out_dir = Path(a.folder), Path(a.out_dir)
    (out_dir / "grades").mkdir(parents=True, exist_ok=True)
    headers = {}
    for h in a.header or []:
        k, _, v = h.partition(":")
        headers[k.strip()] = v.strip()

    pdfs = sorted(p for p in folder.glob("*.pdf"))
    if not pdfs:
        sys.exit(f"No PDF files found in {folder}")

    csv_path = out_dir / "results.csv"
    new_file = not csv_path.exists()
    lock = threading.Lock()  # keeps printing and the CSV tidy when several quizzes run at once
    fh = open(csv_path, "a", newline="", encoding="utf-8-sig")
    log = csv.writer(fh)
    if new_file:
        log.writerow(["file", "examId", "awarded", "possible", "percent", "status", "notes"])

    def say(msg):
        with lock:
            print(msg, flush=True)

    def work(i, pdf):
        target = out_dir / f"{pdf.stem} - graded.pdf"
        if target.exists() and not a.overwrite:
            say(f"[{i}/{len(pdfs)}] {pdf.name}: already done, skipping")
            return
        say(f"[{i}/{len(pdfs)}] {pdf.name}: grading ...")
        try:
            g = _call_webhook(requests, a.webhook, pdf, a.exam_id, headers, a.retries, a.timeout, grid=a.grid)
            (out_dir / "grades" / f"{pdf.stem}.grades.json").write_text(
                json.dumps(g, indent=2, ensure_ascii=False), encoding="utf-8")
            data, warns = stamp_pdf(pdf.read_bytes(), g, add_feedback=not a.no_feedback)
            target.write_bytes(data)
            ng = normalise_grades(g)
            pct = round(ng["totalAwarded"] / ng["totalPossible"] * 100) if ng["totalPossible"] else 0
            status = "check" if any(q.get("notGraded") for q in ng["questions"]) else "ok"
            say(f"[{i}/{len(pdfs)}] {pdf.name}: {_fmt(ng['totalAwarded'])}/{_fmt(ng['totalPossible'])} ({pct}%)"
                + (f"  [{len(warns)} warning(s)]" if warns else ""))
            row = [pdf.name, ng["examId"], _fmt(ng["totalAwarded"]), _fmt(ng["totalPossible"]),
                   pct, status, "; ".join(warns)]
        except Exception as e:
            say(f"[{i}/{len(pdfs)}] {pdf.name}: FAILED: {e}")
            row = [pdf.name, "", "", "", "", "failed", str(e)[:300]]
        with lock:
            log.writerow(row)
            fh.flush()
        time.sleep(a.delay)

    try:
        with ThreadPoolExecutor(max_workers=max(1, a.workers)) as pool:
            for i, pdf in enumerate(pdfs, 1):
                pool.submit(work, i, pdf)
    finally:
        fh.close()
    print("Done. See", csv_path)


def main():
    ap = argparse.ArgumentParser(description="Stamp graded quizzes locally (free replacement for PDF.co).")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("single", help="stamp one PDF from a saved grades JSON file")
    s.add_argument("--pdf", required=True)
    s.add_argument("--grades", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--no-feedback", action="store_true", help="do not append the feedback pages")
    s.set_defaults(fn=cmd_single)

    b = sub.add_parser("batch", help="grade every PDF in a folder via the n8n webhook, then stamp it")
    b.add_argument("--folder", required=True, help="folder with the quiz PDFs")
    b.add_argument("--out-dir", required=True, help="where graded PDFs, grades JSON and results.csv go")
    b.add_argument("--webhook", required=True, help="n8n production webhook URL")
    b.add_argument("--exam-id", default=None, help="sent as examId (workflow defaults to 9280R-Nov24)")
    b.add_argument("--header", action="append", help='extra header, e.g. --header "X-Token: secret"')
    b.add_argument("--workers", type=int, default=1,
                   help="how many quizzes to grade at the same time (try 3; too many can hit rate limits)")
    b.add_argument("--delay", type=float, default=1.0, help="seconds to wait after each quiz")
    b.add_argument("--retries", type=int, default=1, help="extra tries if a grading call fails (each try costs again)")
    b.add_argument("--timeout", type=int, default=900, help="seconds to wait for each quiz to finish grading")
    b.add_argument("--overwrite", action="store_true", help="redo quizzes that already have a graded PDF")
    b.add_argument("--no-feedback", action="store_true")
    b.add_argument("--grid", action="store_true", help="(experimental) draw a measuring grid on the copy sent to the model")
    b.set_defaults(fn=cmd_batch)

    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
